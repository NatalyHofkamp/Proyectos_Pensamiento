from main_functions import menu
def main():
    """
    this funtions indicates the beggining of the game and estructurates
    the start of the main menu
    """
    print("Let's play hangman!")
    menu()

if __name__== '__main__':
    main() 
