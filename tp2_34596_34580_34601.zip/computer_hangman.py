from es_ES import words
from functions import character_in_the_word, lose
def filter_words(possible_words, hidden_word,letters_used):
    """
    Given the hidden_word and the position of the letters that have been
    discovered in it,the words for the list of possible words that don´t
    match witch the that letter´s placement get removed form the list of
    possible words. 
    Parameters
    ----------
    possible_words : list
        list of every word that meets the conditions to be a candidate for 
        the secret word.
    hidden_word : list
        A list of characters that represents the ammount of letters 
        that compose the secret word.
    letters_used : list
        list of letter that were given as a guess by the program.
    """
    for counter in range (0,len(hidden_word)):
        for word1 in possible_words:
            if hidden_word[counter] == '_':
                pass
            else: 
                if word1[counter] == hidden_word[counter]:
                    pass
                else:
                    possible_words.remove(word1)    
            
def choice(possible_words,letters_to_use,word):
    """
    Computes the ammount of total apparitions of every letter in all words 
    from the possible words list. Based in those numbers, it chooses the most
    used letter to risk it in the computer hangman game mode.
    Parameters
    ----------
    possible_words: list
        list of every word that meets the conditions to be a candidate for 
        the secret word.
    letters_to_use : list
        list of every letter from the alphabet wich haven´t been selected yet.
    word : string
        The secret word.
    Returns
    -------
    character: string
        Letter selected by the computer wich is probable of being part of the 
        secret word.
    """
    letter_amount = []
    for i in range(0,len(letters_to_use)):
        s=0
        for word1 in possible_words:
            amount_letter = word1.count(letters_to_use[i])
            s+= amount_letter
        letter_amount.append(s)
    value = max(letter_amount)
    index = letter_amount.index(value)
    character = letters_to_use[index]
    letters_to_use.remove(character)
    return character


def computer_wins (hidden_word:str):
    """
    Once the game finishes, the function win prints a message giving the player 
    the indication that the computer has guessed the word given.
    Parameters
    ----------
    hidden_ word : str
        The secret word selected in the game.
    Returns
    -------
    play_again : function
        function used to ask the player if they want to play again.
    """
    word2 = ''.join(hidden_word)
    print(f"I discovered the word!, it is '{word2}'!")
def lose_lie():
    """
    prints a message accusing the player of being a liar, because they
    gave a wrong answer to the question if the letter was or wasn't in
    the word given.
    """
    print("you lied to me, that´s why i couldn't guess the word.")

def wins_lie():
    """
    prints a message accusing the player of being a liar, because they
    gave a wrong answer to the question if the letter was or wasn't in
    the word given.
    """
    
    print("I guessed the word, but you lied to me.")
def computer_hangman():
    """
    Second mode of the hangman game, in this game mode the user selects a 
    word from the whole list of the diccionary and then the computer begings
    to guess letter by letter from the word until it´s fully guessed and wins
    the game, or the program runs out of tries and looses the game It shows 
    the letters risked, the ammonut of letter of the secret word that have 
    been guessed and the remeining ones to be discovered.
    Returns
    -------
    lie: function
        function that prints a message accusing the player of liying.
    win: function
        prints a message giving the user the indication that he has won
    lose: function  
        prints a message giving the user the indication that he has lost
    """
    possible_words=[]
    word = input("Please, input a word for the computer to guess: ")
    word = word.lower()
    for word1 in list(words):
        if len(word1) == len(word):
            possible_words.append(word1)
    tries = 5
    while word not in words:
        print(f'{word} is not in the list of possible words')
        word= input("Please, input a word for the computer to guess: ")
    print ('Secret word saved!')
    hidden_word = "_" * len(word)
    letters_to_use= ["a","b","c","d","e","f","g","h",
                     "i","j","k","l","m","n","o","p",
                     "q","r","s","t","u","v","w","x","y","z"]
    letters_used = []
    mistake=0
    while tries in range (1,6) :
        if tries == 1:
            print (' 1 try remaining')
        else:
            print (f'{tries} tries remaining')
        hidden_word=list(hidden_word)
        word1=' '.join(hidden_word)
        letters1_used = ''.join(letters_used)
        if len(letters_used) == 0:
            print (word1)
        else :
            print (f'{word1} ({letters1_used})')
        if not '_' in hidden_word and mistake!=0:
            return wins_lie()
        elif not '_' in hidden_word and mistake == 0:
            return computer_wins(hidden_word)
        character = choice(possible_words,
                           letters_to_use,
                           word
                           )
        question1 = input(f"Is the letter '{character}' present in the word? [y/n]:")
        letters_used.append(character)
        if question1== 'y' and  character not in word:
            mistake +=1
        elif question1== 'y' and  character in word:
                character_in_the_word(character,
                                      hidden_word,
                                      letters_used,
                                      word,
                                      tries
                                      )
                filter_words(possible_words,
                               hidden_word,
                               letters_used
                               )      
        elif question1 == 'n':   
            tries-=1
            if character in word:
                mistake +=1
            elif character not in word:
                for index,word1 in enumerate(possible_words):
                    if character in word1:
                        del possible_words[index]
        else:
            print ('Please enter "y" or "n')
    if mistake != 0 :
        return lose_lie()        
    else:
        lose(tries,
             word,
             letters_used,
             hidden_word)
