def character_in_the_word(character,
                          hidden_word,
                          letters_used,
                          word,
                          tries,):
    """
    Modifies hidden_word to concur in the specific character 
    that has been guessed by the user.
    Parameters
    ----------
    character : string
        Letter that the program risks it´s part of the secret word.
    hidden_word : list
        A list of characters that represents the ammount of letters 
        that compose the secret word.
    letters_used : list
        list of letter that were selected.
    word : string
        The secret word.
    tries : int
        Ammount of tries left  untill the game comes to its end.
    """
    word=list(word)
    for index,value in enumerate(word):
        if character == value :
            hidden_word[index]=value

def lose (tries:int,word:str,letters_used:list,hidden_word:list):
    """
    Once the game finishes, the function win prints a message giving the 
    user the indication that he has lost.
    Parameters
    ----------
    word : str
        The secret word selected in the game.
    letters_used : list
        A list of the letters given by the user/computer in order to 
        guess the secret word .
    hidden_word : list
        A list of characters that represents the ammount of letters 
        that compose the secret word.
    
    Returns
    -------
    play_again : function
        function used to ask the player if they want to play again.
    """
    word=''.join(word)
    print (f'Bad luck! there are no more tries. The word was : {word} ')
