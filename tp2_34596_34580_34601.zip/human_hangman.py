from es_ES import words
import random
from functions import  lose, character_in_the_word
def more_characters(character,word):
    """
    When the user wants to try and guess the full word this functions 
    computes if the supossed word is correct.
    Parameters
    ----------
    character : string
        A word decided by the user that is used as a try to guess the word.
    word : string
        The secret word selected in the game.
    Returns
    -------
    play_again : function
        function used to ask the player if they want to play again.
    """
    word=''.join(word)
    if character == word :
       print(f'Congratulations! The word was {word} and you discovered it!')
      
    else:
         print(f'Bad luck! There are no more tries. The word was: {word}')
         
def human_wins (hidden_word:str):
    """
    Once the game finishes, the function win prints a message giving the player 
    the indication that they have won.
    Parameters
    ----------
    hidden_ word : str
        The secret word selected in the game.
    Returns
    -------
    play_again : function
        function used to ask the player if they want to play again.
    """
    word2 = ''.join(hidden_word)
    print(f"Congratulations! The word was '{word2}' and you discovered it!")
    
def human_hangman(): 
    """
    First mode of the hangman game, the program takes a random word from a 
    list of words based in the spanish vocabulary. Takes entrys of letter 
    from the user in order for them to guess the random word until they ran 
    out of tries or they discover the word.
    Returns
    -------
    win: function
        Function that indicates the user that they have won the game.
    lose: function
        Function that indicates the user that they have lost the game.
    more_characters: function
        When the user wants to try and guess the full word this functions
        computes if the supossed word is correct.
    """
    es_diccionary = list(words)
    word = random.choice(es_diccionary)
    hidden_word = "_" * len(word)
    tries = 5
    letters_used= []
    while tries in range (1,6):
        if tries == 1:
            print (' 1 try remaining')
        else:
            print (f'{tries} tries remaining')
        hidden_word=list(hidden_word)
        word1= ' '.join(hidden_word)
        letters1 = ''.join(letters_used)
        if len(letters_used) == 0:
            print (word1)
        else :
            print (f'{word1} ({letters1})')
        if not '_' in hidden_word:
            return human_wins(hidden_word)
        character = input ("Choose a character: ")
        character= character.lower()
        if len(character)==1 and character not in letters_used:
            letters_used.append(character)
            if character in word:
                character_in_the_word (character,
                            hidden_word,
                            letters_used,
                            word,
                            tries)
            else:
                tries-=1
        elif character in letters_used:
             print('Be careful, you have already used this word!')
        else: 
            return more_characters(character,
                                   word)
    lose(tries,
         word,
         letters_used,
         hidden_word)
