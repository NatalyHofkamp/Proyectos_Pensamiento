from human_hangman import human_hangman
from computer_hangman import computer_hangman 
from es_ES import words
import sys 

def end_game ():
    """
    Function used to close the game.
    Returns
    -------
    sys.exit: function
        ends the code run.
    """
    print('Good bye, have a nice day!')
    return sys.exit
def see_words_list():
    """
    this function will show in the console the list of words available for 
    the player to select.
    """
    list_words = list(words)
    list_words = ', '.join(words)
    print(f'List of possible words : {list_words}')
    

def menu():
    """
    Main manu of the game, ir gives the player to input the option they 
    want the algorithm to excute: 1_ Play one oh the 2 game modes 
            2_ See the complete list of words from the diccionary
            3_ Exit the game
    Returns
    -------
    End_game: function
    Function that shuts down the game.
    
    """
    while True: 
        print("What do you want to do? \n 1. Play \n 2. See words list \n 3. Quit")
        gral_option = int(input("Select at most one option > "))
        while gral_option != 1 and gral_option != 2 and gral_option != 3:
            print("Error choosing option . Please enter a valid number")
            gral_option= int(input("Select at most one option > "))
        if gral_option == 1:
            print("How do you want to play? \n 1. Human Hangman \n 2. Computer Hangman \n 3. Go back")
            option = int(input("Select at most one option > "))
            while option != 1 and option != 2 and option != 3:
                print("Error choosing option . Please enter a valid number")
                option= int(input("Select at most one option > "))
            if option == 1:
                human_hangman()
            elif option == 2:
                computer_hangman()
            elif option == 3:
                continue
        elif gral_option == 2:
            see_words_list()
        elif gral_option == 3:
            end_game()
            break
                
    
    

